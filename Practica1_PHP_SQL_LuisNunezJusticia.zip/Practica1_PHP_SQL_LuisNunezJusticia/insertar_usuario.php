<form action="insertar_usuario2.php" method="get">
    <p> Nombre: <input type="text" name="nombre" size="40"></p>
    <p> Email: <input type="text" name="correo" size="40"></p>	
    <p> clave: <input type="text" name="password" size="40"></p>
    <input type="submit" value="Enviar">
    <input type="reset" value="Borrar">
 
</form>

<a href="menu.html">Volver</a>