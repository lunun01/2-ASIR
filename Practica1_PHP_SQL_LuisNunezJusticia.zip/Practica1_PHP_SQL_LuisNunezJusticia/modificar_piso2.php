<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crea conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba:
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}

$cod_piso=$_REQUEST["cod_piso"];
$sql = "SELECT Codigo_piso, calle, numero, piso, puerta, cp, metros, zona, precio, imagen, usuario_id FROM pisos where Codigo_piso='$cod_piso'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) 
{
 // Muestra los datos de la fila buscada
 $row = mysqli_fetch_assoc($result);   
  
  echo "<h1> Datos: </h1>";
  echo "<form action='modificar_piso3.php' method='get'>";

  echo " <p> El Id es :  <input type='text' name='cod_piso' value=".$row['Codigo_piso']." readonly>";    
  echo " <p> Calle: <input type='text' name='calle' value=".$row['calle']." ></p>";
  echo " <p> Numero: <input type='text' name='numero' value=".$row['numero']."></p>";
  echo " <p> Piso: <input type='text' name='piso' value=".$row['piso']."></p>";
  echo " <p> Puerta: <input type='text' name='puerta' value=".$row['puerta']."></p>";
  echo " <p> CP: <input type='text' name='cp' value=".$row['cp']."></p>";
  echo " <p> metros: <input type='text' name='metros' value=".$row['metros']."></p>";
  echo " <p> Zona: <input type='text' name='zona' value=".$row['zona']."></p>";
  echo " <p> Precio: <input type='text' name='precio' value=".$row['precio']."></p>";
  echo " <p> Imagen anterior: <input type='text' name='imagen' value=".$row['imagen']." readonly></p>";
  echo " <p> Si no desea modificar la imagen , vuelva a seleccionar la imagen que ya estaba asignada</p>";
  echo " <p> Imagen nueva: <input type='file' name='imagen_nueva'></p>";
  echo " <p> Usuario_id: <input type='text' name='usuario_id' value=".$row['usuario_id']."></p>";

   
  echo " <input type='submit' value='Enviar'>";
  echo " <input type='reset' value='Borrar'>";
     
  echo "</form>";
  echo '<a href="modificar_piso.php">Volver</a>';
} else {
    echo "No existe ese piso";
}
mysqli_close($conn);
?>