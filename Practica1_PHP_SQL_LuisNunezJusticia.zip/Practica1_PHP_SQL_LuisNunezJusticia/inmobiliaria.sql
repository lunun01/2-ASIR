CREATE DATABASE inmobiliaria;

USE inmobiliaria;


CREATE TABLE usuario (
 usuario_id int(5) NOT NULL AUTO_INCREMENT primary key,
 nombres varchar(35) NOT NULL,
 correo varchar(100) NOT NULL,
 clave varchar(80) NOT NULL
 );

CREATE TABLE pisos (
Codigo_piso int primary key,
calle VARCHAR(40) NOT NULL,
numero INT NOT NULL,
piso INT NOT NULL,
puerta VARCHAR(5) NOT NULL,
cp INT NOT NULL,
metros INT NOT NULL,
zona VARCHAR (15),
precio float NOT NULL,
imagen varchar(100) NOT NULL,
usuario_id int(5) references usuario
);

INSERT INTO usuario (nombres, correo, clave)
VALUES ('John Smith', 'johnsmith@example.com', 'password123'),
('Jane Smith', 'janesmith@example.com', 'password456'),
('Luis', 'luis.justicia@gmail.com', '1234');

INSERT INTO pisos (Codigo_piso, calle, numero, piso, puerta, cp, metros, zona, precio, imagen, usuario_id)
VALUES (1, 'Main Street', 123, 1, 'A', 12345, 50, 'Downtown', 500.00, 'piso1.jpg', 1),
(2, 'Maple Avenue', 456, 2, 'B', 56789, 75, 'Suburbs', 750.00, 'piso2.jpg', 2),
(3, 'Oak Street', 789, 3, 'C', 90123, 100, 'Downtown', 1000.00, 'piso3.jpg', 3);