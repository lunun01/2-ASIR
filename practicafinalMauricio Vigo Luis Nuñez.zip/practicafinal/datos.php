<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "rootroot";
$dbname = "final";
?>