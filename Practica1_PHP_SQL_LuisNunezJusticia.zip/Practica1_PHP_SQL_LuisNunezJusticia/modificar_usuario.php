<h1> Buscar: </h1>
<form action="modificar_usuario2.php" method="get">
  <p>Nombre usuario: <input type="text" name="nombre" size="40"></p>

    <input type="submit" value="Enviar">
    <input type="reset" value="Borrar">

</form>

<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crea conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Compruebar errores:
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT usuario_id, nombres, correo FROM usuario;";
$result = mysqli_query($conn, $sql); //ejecutar la select
echo '<a href="menu.html">Volver</a>';
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <b><font face="Arial">Usuario_id</font></b> </td> 
          <td> <b><font face="Arial">Nombres</font></b> </td> 
          <td> <b><font face="Arial">Correo</font></b> </td> 
      </tr>';

if (mysqli_num_rows($result) > 0) 
{
 // Muestra los datos fila fila
  while($row = mysqli_fetch_assoc($result)) {
    $field1name = $row["usuario_id"];
    $field2name = $row["nombres"];
    $field3name = $row["correo"];
    echo '<tr> 
              <td>'.$field1name.'</td> 
              <td>'.$field2name.'</td> 
              <td>'.$field3name.'</td> 
          </tr>';
  }
} else {
    echo "No hay datos";
}
mysqli_close($conn);

?>
