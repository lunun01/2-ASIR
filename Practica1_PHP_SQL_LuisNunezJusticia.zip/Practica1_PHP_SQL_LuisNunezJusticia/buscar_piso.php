<h1> Buscar: </h1>
<form action="buscar_piso2.php" method="get">
  <p>Codigo_piso: <input type="text" name="cod_piso" size="40"></p>

    <input type="submit" value="Enviar">
    <input type="reset" value="Borrar">

</form>
<a href="menu.html">Volver</a>