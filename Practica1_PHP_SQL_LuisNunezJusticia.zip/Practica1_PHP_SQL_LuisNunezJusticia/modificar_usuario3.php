<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crear la Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba la conexion
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$nombre=$_REQUEST["nombre"];
$email=$_REQUEST["correo"];
// Comando SQL de actualizar

$sql = "UPDATE usuario SET nombres='$nombre', correo='$email' WHERE nombres='$nombre'";
if (mysqli_query($conn, $sql)) {
echo "Usuario actualizado correctamente";
echo "<br>";
echo '<a href="modificar_usuario.php">Volver</a>';

} else {
 echo "Error actualizando: " . mysqli_error($conn);
}
mysqli_close($conn);
?>