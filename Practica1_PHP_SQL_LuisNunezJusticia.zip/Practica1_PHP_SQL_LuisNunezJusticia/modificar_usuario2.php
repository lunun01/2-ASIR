<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crea conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba:
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}

$nombre_usuario=$_REQUEST["nombre"];
$sql = "SELECT usuario_id, nombres, correo FROM usuario where nombres='$nombre_usuario'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) 
{
 // Muestra los datos de la fila buscada
 $row = mysqli_fetch_assoc($result);   
  
  echo "<h1> Datos: </h1>";
  echo "<form action='modificar_usuario3.php' method='get'>";

  echo " <p> El Id es :  <input type='text' name='usuario_id' value=".$row['usuario_id']." readonly>";    
  echo " <p> Nombre: <input type='text' name='nombre' value=".$row['nombres']." ></p>";
  echo " <p> Apellido: <input type='text' name='correo' value=".$row['correo']."></p>";
    
  echo " <input type='submit' value='Enviar'>";
  echo " <input type='reset' value='Borrar'>";
     
  echo "</form>";
  echo '<a href="modificar_usuario.php">Volver</a>';
} else {
    echo "No existe ese usuario";
}
mysqli_close($conn);
?>