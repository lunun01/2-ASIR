<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crea conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba:
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$cod_piso=$_REQUEST["cod_piso"];
$sql = "SELECT Codigo_piso, calle, numero, piso, puerta, cp, metros, zona, precio, imagen, usuario_id FROM pisos where Codigo_piso='$cod_piso'";
$result = mysqli_query($conn, $sql);

echo '<a href="menu.html">Volver</a>';
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <b><font face="Arial">Codigo_piso</font></b> </td> 
          <td> <b><font face="Arial">Calle</font></b> </td> 
          <td> <b><font face="Arial">Numero</font></b> </td>
          <td> <b><font face="Arial">Piso</font></b> </td> 
          <td> <b><font face="Arial">Puerta</font></b> </td> 
          <td> <b><font face="Arial">CP</font></b> </td> 
          <td> <b><font face="Arial">Metros</font></b> </td>
          <td> <b><font face="Arial">Zona</font></b> </td> 
          <td> <b><font face="Arial">Precio</font></b> </td> 
          <td> <b><font face="Arial">Imagen</font></b> </td> 
          <td> <b><font face="Arial">Usuario_id</font></b> </td>   
      </tr>';
//echo $sql;
if (mysqli_num_rows($result) > 0) 
{
 // Muestra los datos fila fila
  while($row = mysqli_fetch_assoc($result)) {
    $field1name = $row["Codigo_piso"];
    $field2name = $row["calle"];
    $field3name = $row["numero"];
    $field4name = $row["piso"];
    $field5name = $row["puerta"];
    $field6name = $row["cp"];
    $field7name = $row["metros"];
    $field8name = $row["zona"];
    $field9name = $row["precio"];
    $field10name = $row["imagen"];
    $field11name = $row["usuario_id"];
    echo '<tr> 
              <td>'.$field1name.'</td> 
              <td>'.$field2name.'</td> 
              <td>'.$field3name.'</td> 
              <td>'.$field4name.'</td> 
              <td>'.$field5name.'</td> 
              <td>'.$field6name.'</td> 
              <td>'.$field7name.'</td> 
              <td>'.$field8name.'</td> 
              <td>'.$field9name.'</td> 
              <td>'.$field10name.'</td> 
              <td>'.$field11name.'</td> 
          </tr>';
  }
} else {
    echo "No hay datos";
}
mysqli_close($conn);
?>