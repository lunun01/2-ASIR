<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crear la Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba la conexion
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}

$cod_piso=$_REQUEST["cod_piso"];
$calle=$_REQUEST["calle"];
$numero=$_REQUEST["num"];
$piso=$_REQUEST["piso"];
$puerta=$_REQUEST["puerta"];
$cod_pos=$_REQUEST["cod_pos"];
$metros=$_REQUEST["metros"];
$zona=$_REQUEST["zona"];
$precio=$_REQUEST["precio"];
$imagen=$_REQUEST["imagen"];
$cod_usu=$_REQUEST["cod_usu"];
// Comando SQL de insertar
$sql = "INSERT INTO pisos (Codigo_piso, calle, numero, piso, puerta, cp, metros, zona, precio, imagen, usuario_id) VALUES
        ('$cod_piso', '$calle', '$numero', '$piso', '$puerta', '$cod_pos', '$metros', '$zona', '$precio', '$imagen', '$cod_usu')";
//Ejecuta el insert y controla el error.

if (mysqli_query($conn, $sql)) {
    echo "Piso añadido correctamente";
    echo "<br>";
    echo '<a href="menu.html">Volver</a>';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "<br>";
    echo '<a href="menu.html">Volver</a>';
}
mysqli_close($conn);
?>
<form action="añadir_piso.php" method="post">
    <p> Codigo piso: <input type="text" name="cod_piso" size="40"></p>
    <p> Calle: <input type="text" name="calle" size="40"></p>	
    <p> Número: <input type="text" name="num" size="40"></p>
    <p> Piso: <input type="text" name="piso" size="40"></p>
    <p> Puerta: <input type="text" name="puerta" size="40"></p>
    <p> CP: <input type="text" name="cod_pos" size="40"></p>
    <p> Metros: <input type="text" name="metros" size="40"></p>
    <p> Zona: <input type="text" name="zona" size="40"></p>
    <p> Precio: <input type="text" name="precio" size="40"></p>
    <p> Imagen: <input type="file" name="imagen" size="40"></p>
    <p> Usuario id: <input type="text" name="cod_usu" size="40"></p>
    <input type="submit" value="Enviar">
    <input type="reset" value="Borrar">
 
</form>

<a href="menu.html">Volver</a>