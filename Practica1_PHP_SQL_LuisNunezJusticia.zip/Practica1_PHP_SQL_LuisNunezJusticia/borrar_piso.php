<h1> Buscar: </h1>
<form action="borrar_piso2.php" method="get">
  <p>Codigo Piso: <input type="text" name="cod_piso" size="40"></p>

    <input type="submit" value="Enviar">
    <input type="reset" value="Borrar">

</form>

<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crea conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Compruebar errores:
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT Codigo_piso, calle, numero, piso, puerta, cp, metros, zona, precio, imagen, usuario_id FROM pisos;";
$result = mysqli_query($conn, $sql); //ejecutar la select
echo '<a href="menu.html">Volver</a>';
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <b><font face="Arial">Codigo_piso</font></b> </td> 
          <td> <b><font face="Arial">Calle</font></b> </td> 
          <td> <b><font face="Arial">Numero</font></b> </td>
          <td> <b><font face="Arial">Piso</font></b> </td> 
          <td> <b><font face="Arial">Puerta</font></b> </td> 
          <td> <b><font face="Arial">CP</font></b> </td> 
          <td> <b><font face="Arial">Metros</font></b> </td>
          <td> <b><font face="Arial">Zona</font></b> </td> 
          <td> <b><font face="Arial">Precio</font></b> </td> 
          <td> <b><font face="Arial">Imagen</font></b> </td> 
          <td> <b><font face="Arial">Usuario_id</font></b> </td>   
      </tr>';

if (mysqli_num_rows($result) > 0) 
{
 // Muestra los datos fila fila
  while($row = mysqli_fetch_assoc($result)) {
    $field1name = $row["Codigo_piso"];
    $field2name = $row["calle"];
    $field3name = $row["numero"];
    $field4name = $row["piso"];
    $field5name = $row["puerta"];
    $field6name = $row["cp"];
    $field7name = $row["metros"];
    $field8name = $row["zona"];
    $field9name = $row["precio"];
    $field10name = $row["imagen"];
    $field11name = $row["usuario_id"];
    echo '<tr> 
              <td>'.$field1name.'</td> 
              <td>'.$field2name.'</td> 
              <td>'.$field3name.'</td> 
              <td>'.$field4name.'</td> 
              <td>'.$field5name.'</td> 
              <td>'.$field6name.'</td> 
              <td>'.$field7name.'</td> 
              <td>'.$field8name.'</td> 
              <td>'.$field9name.'</td> 
              <td><img src="./img/'.$field10name.'" width="100px" height="100px"></td> 
              <td>'.$field11name.'</td> 
          </tr>';
  }
} else {
    echo "No hay datos";
}
mysqli_close($conn);
?>