<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crear la Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba la conexion
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$nombre=$_REQUEST["nombre"];
$email=$_REQUEST["correo"];
$clave=$_REQUEST["password"];
// Comando SQL de insertar
$sql = "INSERT INTO usuario (nombres, correo, clave) VALUES
        ('$nombre', '$email', '$clave')";
//Ejecuta el insert y controla el error.

if (mysqli_query($conn, $sql)) {
    echo "Usuario añadido correctamente";
    echo "<br>";
    echo '<a href="menu.html">Volver</a>';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "<br>";
    echo '<a href="menu.html">Volver</a>';
}
mysqli_close($conn);
?>