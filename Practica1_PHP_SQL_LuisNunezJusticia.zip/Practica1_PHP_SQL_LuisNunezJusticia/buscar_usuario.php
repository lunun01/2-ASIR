<h1> Buscar: </h1>
<form action="buscar_usuario2.php" method="get">
  <p>Nombre usuario: <input type="text" name="nombre" size="40"></p>

    <input type="submit" value="Enviar">
    <input type="reset" value="Borrar">

</form>
<a href="menu.html">Volver</a>