<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crear la Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba la conexion
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$nombre_usuario=$_REQUEST["nombre"];
// Comando SQL de insertar
$sql = "DELETE FROM usuario where nombres='$nombre_usuario'";

if (mysqli_query($conn, $sql)) {
    echo "Usuario borrado correctamente";
    echo "<br>";
    echo '<a href="borrar_usuario.php">Volver</a>';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "<br>";
    echo '<a href="borrar_usuario.php">Volver</a>';
}
mysqli_close($conn);
?>