<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crea conexion
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba:
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$nombre_usuario=$_REQUEST["nombre"];
$sql = "SELECT usuario_id, nombres, correo FROM usuario where nombres='$nombre_usuario'";
$result = mysqli_query($conn, $sql);

echo '<a href="buscar_usuario.php">Volver</a>';
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <b><font face="Arial">Usuario_id</font></b> </td> 
          <td> <b><font face="Arial">Nombres</font></b> </td> 
          <td> <b><font face="Arial">Correo</font></b> </td> 
      </tr>';
//echo $sql;
if (mysqli_num_rows($result) > 0) 
{
 // Muestra los datos fila fila
  while($row = mysqli_fetch_assoc($result)) {
    $field1name = $row["usuario_id"];
    $field2name = $row["nombres"];
    $field3name = $row["correo"];
    echo '<tr> 
              <td>'.$field1name.'</td> 
              <td>'.$field2name.'</td> 
              <td>'.$field3name.'</td> 
          </tr>';
  }
} else {
    echo "No hay datos";
}
mysqli_close($conn);
?>