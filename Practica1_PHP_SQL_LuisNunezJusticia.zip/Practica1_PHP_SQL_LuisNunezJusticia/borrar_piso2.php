<?php
$servername = "localhost";
$username = "root";
$password = "rootroot";
$dbname = "inmobiliaria";
// Crear la Conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Comprueba la conexion
if (!$conn) {
 die("Connection failed: " . mysqli_connect_error());
}
$cod_piso=$_REQUEST["cod_piso"];
// Comando SQL de insertar
$sql = "DELETE FROM pisos where Codigo_piso='$cod_piso'";

if (mysqli_query($conn, $sql)) {
    echo "Piso borrado correctamente";
    echo "<br>";
    echo '<a href="borrar_piso.php">Volver</a>';
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    echo "<br>";
    echo '<a href="borrar_piso.php">Volver</a>';
}
mysqli_close($conn);
?>